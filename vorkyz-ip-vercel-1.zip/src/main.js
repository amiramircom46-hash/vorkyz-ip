import { createClient } from "@supabase/supabase-js";
import "./style.css";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const root = document.querySelector("#app");
const configured = SUPABASE_URL && SUPABASE_ANON_KEY &&
  !SUPABASE_URL.includes("YOUR_PROJECT") && !SUPABASE_ANON_KEY.includes("YOUR_");
const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
let mode = "login", session = null, results = [];

const icon = `<div class="logo">VI</div>`;
function authView(message="") {
  root.innerHTML = `<section class="auth-wrap"><div class="auth-card">${icon}
    <h1>${mode==="login"?"Masuk ke VORKYZ IP":"Buat akun VORKYZ IP"}</h1>
    <p class="muted center">Kelola generator username dan IP kamu dalam satu dashboard.</p>
    <form id="auth-form">
      <label for="email">Email</label><input id="email" type="email" placeholder="email kamu" autocomplete="email" required>
      <label for="password">Password</label><input id="password" type="password" placeholder="Minimal 6 karakter" minlength="6" autocomplete="${mode==="login"?"current-password":"new-password"}" required>
      <button class="primary" type="submit">${mode==="login"?"Masuk":"Daftar"}</button>
      <p class="message" id="message">${message}</p>
    </form>
    <p class="switch">${mode==="login"?'Belum punya akun? <a id="switch">Daftar</a>':'Sudah punya akun? <a id="switch">Masuk</a>'}</p>
  </div></section>`;
  document.querySelector("#switch").onclick=()=>{mode=mode==="login"?"register":"login";authView()};
  document.querySelector("#auth-form").onsubmit=async e=>{
    e.preventDefault(); const btn=e.currentTarget.querySelector("button"); btn.disabled=true; btn.textContent="Memproses...";
    const email=document.querySelector("#email").value.trim(), password=document.querySelector("#password").value;
    const action=mode==="login"?supabase.auth.signInWithPassword({email,password}):supabase.auth.signUp({email,password});
    const {data,error}=await action;
    if(error){document.querySelector("#message").textContent=error.message;btn.disabled=false;btn.textContent=mode==="login"?"Masuk":"Daftar";return}
    if(mode==="register"&&!data.session){document.querySelector("#message").textContent="Akun dibuat. Periksa email untuk konfirmasi, lalu masuk.";btn.disabled=false;btn.textContent="Daftar";return}
    session=data.session; dashboard();
  };
}
function shell(page="dashboard"){
  const email=session?.user?.email||"";
  root.innerHTML=`<div class="layout"><aside class="sidebar"><div class="brand">${icon}<span>VORKYZ IP</span></div>
    <nav><button data-page="dashboard" class="${page==="dashboard"?"active":""}">◫ &nbsp; Dashboard</button><button data-page="generator" class="${page==="generator"?"active":""}">✳ &nbsp; Generator</button><button data-page="history" class="${page==="history"?"active":""}">◷ &nbsp; Riwayat</button></nav>
    <button class="logout" id="logout">↪ &nbsp; Keluar</button></aside>
    <main class="main"><header><div><div class="eyebrow">WORKSPACE</div><h2 id="title">${page[0].toUpperCase()+page.slice(1)}</h2></div><div class="user-chip"><span class="avatar">${email.slice(0,1).toUpperCase()}</span><span>${escapeHtml(email)}</span></div></header>
    <section id="content"></section></main></div>`;
  root.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>{shell(b.dataset.page);renderPage(b.dataset.page)});
  document.querySelector("#logout").onclick=async()=>{await supabase.auth.signOut();session=null;authView()};
}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderPage(page){
  const content=document.querySelector("#content");
  if(page==="dashboard"){content.innerHTML=`<div class="welcome panel"><div><span class="tag">VORKYZ IP • CONTROL PANEL</span><h3>Selamat datang 👋</h3><p class="muted">Kelola dan buat data username serta IP untuk kebutuhan testing.</p><button class="primary compact" id="go-gen">Mulai Generate →</button></div><div class="orb">VI</div></div><div class="cards"><article class="panel"><span class="stat-icon">✳</span><h3>Generator</h3><p class="muted">Buat beberapa data secara instan.</p></article><article class="panel"><span class="stat-icon">◷</span><h3>Riwayat</h3><p class="muted">Lihat hasil yang tersimpan di akunmu.</p></article></div><p class="footnote">IP yang dihasilkan adalah alamat acak untuk demo/testing, bukan IP publik yang terdeteksi dari perangkat.</p>`;
    document.querySelector("#go-gen").onclick=()=>{shell("generator");renderPage("generator")};
  } else if(page==="generator"){content.innerHTML=`<div class="panel"><h3>Generator Username & IP</h3><p class="muted">Pilih jumlah data yang ingin dibuat (maksimal 20).</p><div class="generate-row"><div><label for="count">Jumlah data</label><select id="count"><option>1</option><option>5</option><option>10</option><option>20</option></select></div><button class="primary" id="generate">✳ &nbsp; Generate sekarang</button></div><div id="results"></div></div>`;
    document.querySelector("#generate").onclick=generate;
  } else {content.innerHTML=`<div class="panel"><div class="history-head"><div><h3>Riwayat Generator</h3><p class="muted">Hasil terbaru dari akunmu.</p></div><button class="secondary" id="clear">Hapus semua</button></div><div id="history"><p class="muted">Memuat riwayat...</p></div></div>`;loadHistory();}
}
function dashboard(){shell("dashboard");renderPage("dashboard")}
async function api(path, options={}) {
  const {data:{session:current}}=await supabase.auth.getSession();
  const res=await fetch(path,{...options,headers:{"Content-Type":"application/json","Authorization":`Bearer ${current?.access_token||""}`,...options.headers}});
  const body=await res.json().catch(()=>({}));
  if(!res.ok)throw Error(body.error||"Permintaan gagal.");return body;
}
async function generate(){
  const btn=document.querySelector("#generate"), out=document.querySelector("#results");btn.disabled=true;btn.textContent="Membuat...";
  try{const d=await api("/api/generate",{method:"POST",body:JSON.stringify({count:Number(document.querySelector("#count").value)})});results=d.results;
    out.innerHTML=`<div class="result-head"><b>Hasil generate</b><button class="secondary" id="copy">Salin semua</button></div><div class="result-list">${results.map(x=>`<div class="result-row"><code>${escapeHtml(x.username)}</code><code>${escapeHtml(x.ip)}</code></div>`).join("")}</div>`;
    document.querySelector("#copy").onclick=async()=>{await navigator.clipboard.writeText(results.map(x=>`${x.username},${x.ip}`).join("\\n"));toast("Hasil disalin.")};
  }catch(e){toast(e.message)}finally{btn.disabled=false;btn.textContent="✳  Generate sekarang"}
}
async function loadHistory(){
  const box=document.querySelector("#history");
  try{const d=await api("/api/history");if(!d.history.length){box.innerHTML='<div class="empty">Belum ada riwayat generator.</div>';return}
    box.innerHTML=`<div class="table-wrap"><table><thead><tr><th>USERNAME</th><th>IP ADDRESS</th><th>WAKTU</th></tr></thead><tbody>${d.history.map(x=>`<tr><td>${escapeHtml(x.username)}</td><td>${escapeHtml(x.ip)}</td><td>${new Date(x.created_at).toLocaleString("id-ID")}</td></tr>`).join("")}</tbody></table></div>`;
  }catch(e){box.textContent=e.message}
  document.querySelector("#clear").onclick=async()=>{if(!confirm("Hapus seluruh riwayat akun ini?"))return;try{await api("/api/history",{method:"DELETE"});loadHistory();toast("Riwayat dihapus.")}catch(e){toast(e.message)}};
}
function toast(msg){const el=document.createElement("div");el.className="toast";el.textContent=msg;document.body.append(el);setTimeout(()=>el.remove(),2800)}
async function start(){
  if(!configured){root.innerHTML=`<section class="auth-wrap"><div class="auth-card">${icon}<h1>VORKYZ IP</h1><p class="muted center">Konfigurasi Supabase belum diisi.</p><div class="setup"><b>Langkah konfigurasi</b><ol><li>Salin <code>.env.example</code> menjadi <code>.env</code>.</li><li>Isi URL dan anon key dari project Supabase.</li><li>Isi environment variables API di Vercel sesuai README.</li><li>Jalankan ulang project.</li></ol></div></div></section>`;return}
  const {data}=await supabase.auth.getSession();session=data.session;
  if(session)dashboard();else authView();
  supabase.auth.onAuthStateChange((_event,newSession)=>{session=newSession;if(!newSession)authView()});
}
start();
