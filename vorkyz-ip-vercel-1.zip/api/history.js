import {requireUser,methodNotAllowed} from "./_supabase.js";
export default async function handler(req,res){
  if(!["GET","DELETE"].includes(req.method))return methodNotAllowed(res,["GET","DELETE"]);
  try{
    const auth=await requireUser(req,res);if(!auth)return;
    if(req.method==="GET"){
      const {data,error}=await auth.supabase.from("generations").select("id,username,ip_address,created_at").eq("user_id",auth.user.id).order("created_at",{ascending:false}).limit(50);
      if(error)throw error;return res.status(200).json({history:data});
    }
    const {error}=await auth.supabase.from("generations").delete().eq("user_id",auth.user.id);
    if(error)throw error;return res.status(200).json({ok:true});
  }catch(e){console.error(e);return res.status(500).json({error:"Gagal memproses riwayat."});}
}