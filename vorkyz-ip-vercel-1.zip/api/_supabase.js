import { createClient } from "@supabase/supabase-js";

export function getAdmin() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Supabase environment variables belum diatur.");
  return createClient(url, key, {auth:{persistSession:false,autoRefreshToken:false}});
}
export async function requireUser(req, res) {
  const header = req.headers.authorization || "";
  const token = header.replace(/^Bearer\s+/i, "");
  if (!token) { res.status(401).json({error:"Silakan masuk terlebih dahulu."}); return null; }
  const supabase = getAdmin();
  const {data,error} = await supabase.auth.getUser(token);
  if (error || !data.user) { res.status(401).json({error:"Sesi tidak valid atau sudah berakhir."}); return null; }
  return {supabase,user:data.user};
}
export function methodNotAllowed(res, methods) {
  res.setHeader("Allow",methods);return res.status(405).json({error:"Method tidak diizinkan."});
}
