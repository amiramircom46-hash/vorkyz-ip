import {requireUser,methodNotAllowed} from "./_supabase.js";
const pick=a=>a[Math.floor(Math.random()*a.length)];
const username=()=>`${pick(["vork","nova","zen","byte","sky","void","nex","luma","flux","kry"])}${pick(["x","yz","pro","dev","core","zone","id","lab","hub"])}${Math.floor(100+Math.random()*900)}`;
const ipv4=()=>`${Math.floor(Math.random()*223)+1}.${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*254)+1}`;
export default async function handler(req,res){
  if(req.method!=="POST")return methodNotAllowed(res,["POST"]);
  try{
    const auth=await requireUser(req,res);if(!auth)return;
    const count=Math.min(Math.max(Number(req.body?.count)||1,1),20);
    const rows=Array.from({length:count},()=>({user_id:auth.user.id,username:username(),ip_address:ipv4()}));
    const {data,error}=await auth.supabase.from("generations").insert(rows).select("id,username,ip_address,created_at");
    if(error)throw error;
    return res.status(200).json({results:data});
  }catch(e){console.error(e);return res.status(500).json({error:"Gagal membuat data. Periksa konfigurasi database."});}
}