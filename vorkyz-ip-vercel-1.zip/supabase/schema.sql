-- Jalankan di Supabase Dashboard > SQL Editor.
create table if not exists public.generations (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  username text not null,
  ip_address text not null,
  created_at timestamptz not null default now()
);
create index if not exists generations_user_created_idx
  on public.generations(user_id, created_at desc);

alter table public.generations enable row level security;

-- Pengguna hanya dapat membaca, menambah, dan menghapus baris miliknya.
create policy "Users read own generations"
  on public.generations for select to authenticated
  using (auth.uid() = user_id);
create policy "Users insert own generations"
  on public.generations for insert to authenticated
  with check (auth.uid() = user_id);
create policy "Users delete own generations"
  on public.generations for delete to authenticated
  using (auth.uid() = user_id);

grant select, insert, delete on public.generations to authenticated;
grant usage, select on sequence public.generations_id_seq to authenticated;
