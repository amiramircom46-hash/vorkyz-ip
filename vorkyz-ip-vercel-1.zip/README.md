# VORKYZ IP — Vercel + Supabase

Full-stack starter: login/registration via Supabase Auth, Vercel serverless API, per-user generation history, responsive dashboard.

## 1. Buat project Supabase
1. Buat project di https://supabase.com.
2. Buka **SQL Editor**, jalankan isi `supabase/schema.sql`.
3. Buka **Project Settings → API** dan salin Project URL, anon/public key, serta service_role key. Jangan pernah mengekspos service_role key ke browser atau repository publik.
4. Pada **Authentication → URL Configuration**, set Site URL ke domain Vercel setelah deploy. Tambahkan domain preview/production ke Redirect URLs bila dibutuhkan. Jika email confirmation aktif, pengguna perlu mengonfirmasi email sebelum login.

## 2. Konfigurasi lokal
1. Salin `.env.example` menjadi `.env` (jangan commit `.env`).
2. Isi:
   - `VITE_SUPABASE_URL` = Project URL
   - `VITE_SUPABASE_ANON_KEY` = anon/public key
   - `SUPABASE_URL` = Project URL
   - `SUPABASE_SERVICE_ROLE_KEY` = service_role key (server-side only)
3. Jalankan `npm install`, lalu `npm run dev`.
4. Buka URL lokal yang ditampilkan Vite.

## 3. Deploy ke Vercel
1. Upload project ke repository GitHub sendiri.
2. Import repository di https://vercel.com/new.
3. Framework preset: **Vite**; build command `npm run build`; output directory `dist`.
4. Pada Vercel **Project → Settings → Environment Variables**, masukkan ke Production (dan Preview bila perlu):
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
5. Redeploy setelah menambahkan environment variables.
6. Atur Supabase Auth Site URL dan Redirect URLs ke domain Vercel kamu.

## Keamanan dan batasan
- Service role key hanya dibaca fungsi API di server, jangan beri prefix `VITE_`.
- API memvalidasi access token lewat Supabase Auth dan mengikat data ke `auth.users.id`.
- Tabel memakai Row Level Security; policies membatasi akses per pemilik akun.
- Username dan IPv4 adalah data acak untuk demo/testing, bukan IP pengguna yang sedang login, bukan proxy/VPN, dan bukan sarana pelacakan.
- Starter ini belum menerapkan rate limiting, verifikasi CAPTCHA, billing, atau panel admin. Tambahkan sebelum layanan publik berskala besar.
